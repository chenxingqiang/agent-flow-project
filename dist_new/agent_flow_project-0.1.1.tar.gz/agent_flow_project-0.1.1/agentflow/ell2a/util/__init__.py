"""ELL2A utility module."""

from agentflow.ell2a.util.differ import write_commit_message_for_diff

__all__ = ['write_commit_message_for_diff'] 