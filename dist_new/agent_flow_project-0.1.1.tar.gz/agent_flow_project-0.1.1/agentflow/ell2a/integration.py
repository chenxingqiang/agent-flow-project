"""ELL2A integration module."""

from typing import Dict, Any, Optional, List, Callable, Union
from typing_extensions import TypedDict
from functools import wraps
import time
import logging
from . import ELL, Message, MessageRole, MessageType

logger = logging.getLogger(__name__)

class FunctionMetrics(TypedDict):
    calls: int
    total_time: float
    errors: int

class Metrics(TypedDict):
    function_calls: int
    total_execution_time: float
    errors: int
    function_metrics: Dict[str, FunctionMetrics]

class ELL2AIntegration:
    """Singleton class for ELL2A integration."""
    
    _instance = None
    _messages = []
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ELL2AIntegration, cls).__new__(cls)
            cls._instance.enabled = True
            cls._instance.tracking_enabled = True
            cls._instance.config = {
                "default_model": "gpt-4",
                "temperature": 0.7,
                "max_tokens": 2000,
                "simple": {
                    "max_retries": 3,
                    "retry_delay": 1.0,
                    "timeout": 30.0
                },
                "complex": {
                    "max_retries": 3,
                    "retry_delay": 1.0,
                    "timeout": 60.0,
                    "stream": True,
                    "track_performance": True,
                    "track_memory": True
                }
            }
            cls._instance.metrics = {
                "function_calls": 0,
                "total_execution_time": 0.0,
                "errors": 0
            }
        return cls._instance
    
    def __init__(self):
        """Initialize instance attributes."""
        # Initialize all instance attributes
        self._is_initialized = getattr(self, '_is_initialized', False)
        self.config = getattr(self, 'config', {})
        self.ell = getattr(self, 'ell', ELL(messages=[], metadata={}))
        self.enabled = getattr(self, 'enabled', True)
        self.tracking_enabled = getattr(self, 'tracking_enabled', True)
        self.metrics = getattr(self, 'metrics', {
            "function_calls": 0,
            "total_execution_time": 0.0,
            "errors": 0
        })
        self._workflows = getattr(self, '_workflows', {})
        self._messages = getattr(self, '_messages', [])
    
    def _initialize(self) -> None:
        """Initialize ELL2A integration."""
        if not self._is_initialized:
            self.config = {
                "default_model": "gpt-4",
                "temperature": 0.7,
                "max_tokens": 2000,
                "simple": {
                    "max_retries": 3,
                    "retry_delay": 1.0,
                    "timeout": 30.0
                },
                "complex": {
                    "max_retries": 3,
                    "retry_delay": 1.0,
                    "timeout": 60.0,
                    "stream": True,
                    "track_performance": True,
                    "track_memory": True
                }
            }
            self.ell = ELL(
                messages=[],
                metadata={
                    "model": self.config["default_model"],
                    "config": self.config
                }
            )
            self.enabled = True
            self.tracking_enabled = True
            self.metrics = {
                "function_calls": 0,
                "total_execution_time": 0.0,
                "errors": 0,
                "function_metrics": {}
            }
            self._workflows = {}
            self._messages = []
            self._is_initialized = True
    
    def cleanup(self):
        """Reset ELL2A integration state."""
        self._workflows.clear()
        self._messages.clear()
        self.metrics: Metrics = {
            "function_calls": 0,
            "total_execution_time": 0.0,
            "errors": 0,
            "function_metrics": {}
        }
        self.ell.clear_history()
        
    def configure(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Configure ELL2A integration.
        
        Args:
            config: Configuration to apply
        """
        if config:
            if "enabled" in config:
                self.enabled = config["enabled"]
            if "tracking_enabled" in config:
                self.tracking_enabled = config["tracking_enabled"]
            if "model" in config:
                self.config = config  # Replace entire config when model is specified
            else:
                self.config.update(config)  # Otherwise just update existing config
    
    def update_config(self, new_config: Dict[str, Any]):
        """Update configuration.
        
        Args:
            new_config: New configuration parameters
        """
        self.configure(new_config)
    
    async def process_message(self, message: Message) -> Message:
        """Process a message through ELL2A.
        
        Args:
            message: Message to process
            
        Returns:
            Processed message
        """
        if not isinstance(message, Message):
            raise TypeError(f"Expected Message, got {type(message)}")
            
        if not self.enabled:
            # When disabled, return a copy of the input message
            return Message(
                role=message.role,  # Preserve the original role
                content=message.content,
                type=message.type,
                metadata=message.metadata
            )
            
        # Store message in history
        messages = list(self._messages)  # Create a new list
        messages.append(message)
        self._messages = messages
        
        # Update metrics
        self.metrics = {
            **self.metrics,
            "function_calls": self.metrics["function_calls"] + 1
        }
        
        # Return a result message
        response = Message(
            role=MessageRole.ASSISTANT,
            content=message.content,
            type=MessageType.RESULT,
            metadata={
                "model": self.config.get("model", "default"),
                "timestamp": time.time(),
                "type": MessageType.RESULT,
                "status": "success",
                **message.metadata
            }
        )
        return response
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration.
        
        Returns:
            Current configuration
        """
        return self.config.copy()
        
    def get_mode_config(self, mode: str = "simple") -> Dict[str, Any]:
        """Get configuration for specified mode.
        
        Args:
            mode: Configuration mode (simple or complex)
            
        Returns:
            Mode-specific configuration
        """
        base_config = {
            "model": self.config.get("model", self.config["default_model"]),
            "max_tokens": self.config.get("max_tokens", 2000),
            "temperature": self.config.get("temperature", 0.7)
        }
        mode_config = self.config.get(mode, {})
        return {**base_config, **mode_config}
    
    def create_message(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> Message:
        """Create a message.
        
        Args:
            role: Message role
            content: Message content
            metadata: Optional metadata
            
        Returns:
            Message: Created message
        """
        return Message(
            role=MessageRole(role),
            content=content,
            metadata=metadata or {}
        )
    
    def add_message(self, message: Message) -> None:
        """Add a message to the context.
        
        Args:
            message: Message to add
        """
        if not isinstance(message, Message):
            raise TypeError(f"Expected Message object, got {type(message)}")
        self._messages.append(message)
    
    def get_messages(self) -> List[Message]:
        """Get all messages.
        
        Returns:
            List of messages
        """
        return self._messages.copy()
    
    def get_context(self) -> Dict[str, Any]:
        """Get current context.
        
        Returns:
            Current context
        """
        return {
            "messages": self._messages.copy()
        }
    
    def clear_context(self) -> None:
        """Clear current context."""
        self._messages.clear()
    
    def register_workflow(self, workflow_id: str, workflow: Any) -> None:
        """Register a workflow.
        
        Args:
            workflow_id: Workflow ID
            workflow: Workflow instance
        """
        self._workflows[workflow_id] = workflow
    
    def unregister_workflow(self, workflow_id: str) -> None:
        """Unregister a workflow.
        
        Args:
            workflow_id: Workflow ID
        """
        self._workflows.pop(workflow_id, None)
    
    def list_workflows(self) -> List[str]:
        """List registered workflows.
        
        Returns:
            List of workflow IDs
        """
        return list(self._workflows.keys())
    
    def get_metrics(self) -> Metrics:
        """Get metrics.
        
        Returns:
            Current metrics including function-specific metrics
        """
        return self.metrics.copy()
    
    @staticmethod
    def with_ell2a(mode: str = "simple"):
        """Decorator for ELL2A integration."""
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                ell2a = ELL2AIntegration()
                config = ell2a.get_mode_config(mode)
                func_name = func.__name__
                
                start_time = time.time()
                try:
                    # Execute original function
                    result = await func(*args, **kwargs)
                    
                    # Update metrics
                    ell2a.metrics["function_calls"] += 1
                    ell2a.metrics["total_execution_time"] += time.time() - start_time
                    
                    # Create message from function result
                    message = Message(
                        role=MessageRole.USER,
                        content=str(result),
                        metadata={
                            "mode": mode,
                            "function": func_name,
                            "status": "success",
                            **kwargs
                        }
                    )
                    
                    # Process with ELL2A
                    processed = await ell2a.process_message(message)
                    
                    return result
                except Exception as e:
                    # Update error metrics
                    ell2a.metrics["errors"] += 1
                    ell2a.metrics["total_execution_time"] += time.time() - start_time
                    
                    # Create error message
                    error_message = Message(
                        role=MessageRole.USER,
                        content=str(e),
                        metadata={
                            "mode": mode,
                            "function": func_name,
                            "status": "error",
                            "error": str(e),
                            **kwargs
                        }
                    )
                    
                    # Process error with ELL2A
                    processed = await ell2a.process_message(error_message)
                    
                    raise
            return wrapper
        return decorator
    
    @staticmethod
    def track_function():
        """Decorator to track function execution with ELL2A.
        
        Returns:
            Decorated function
        """
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                ell2a = ELL2AIntegration()
                func_name = func.__name__
                
                # Initialize metrics for function if not exists
                if "function_metrics" not in ell2a.metrics:
                    ell2a.metrics["function_metrics"] = {}
                
                function_metrics = ell2a.metrics["function_metrics"]
                if func_name not in function_metrics:
                    function_metrics[func_name] = {
                        "calls": 0,
                        "total_time": 0.0,
                        "errors": 0
                    }
                
                try:
                    # Track function execution
                    start_time = time.time()
                    result = await func(*args, **kwargs)
                    
                    # Update metrics safely
                    func_metrics = function_metrics[func_name]
                    func_metrics["calls"] += 1
                    func_metrics["total_time"] += time.time() - start_time
                    
                    return result
                except Exception as e:
                    # Update error metrics safely
                    function_metrics[func_name]["errors"] += 1
                    raise
                
            return wrapper
        return decorator

# Global instance
ell2a_integration = ELL2AIntegration() 