"""Function decorator for Language Model Providers."""

import functools
from typing import Any, Callable, Dict, Optional, Union
from pydantic import BaseModel, ConfigDict

class FunctionConfig(BaseModel):
    """Configuration for function LMP."""
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    api_params: Dict[str, Any] = {}

def function(
    func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
    api_params: Optional[Dict[str, Any]] = None
) -> Union[Callable, Callable[[Callable], Callable]]:
    """Decorator for function LMP.
    
    Args:
        func: The function to decorate
        name: Function name
        description: Function description
        parameters: Function parameters
        api_params: API parameters
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create function configuration
            config = FunctionConfig(
                name=name or func.__name__,
                description=description or func.__doc__,
                parameters=parameters or {},
                api_params=api_params or {}
            )
            
            # Update kwargs with api_params if provided
            if 'api_params' in kwargs:
                config.api_params.update(kwargs.pop('api_params'))
            
            # Call the function with updated kwargs
            return func(*args, **kwargs)
        
        # Attach configuration to the wrapper
        wrapper.config = FunctionConfig(
            name=name or func.__name__,
            description=description or func.__doc__,
            parameters=parameters or {},
            api_params=api_params or {}
        )
        
        return wrapper
    
    if func is None:
        return decorator
    return decorator(func) 