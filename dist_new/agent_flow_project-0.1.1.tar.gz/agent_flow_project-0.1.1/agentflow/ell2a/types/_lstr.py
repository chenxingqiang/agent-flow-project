"""Language string type for ELL2A."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, ConfigDict

class _lstr(BaseModel):
    """Language string type.
    
    This type represents a string with associated language and metadata.
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    text: str
    language: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __str__(self) -> str:
        """Return the string representation."""
        return self.text
    
    def __eq__(self, other: Any) -> bool:
        """Compare for equality."""
        if isinstance(other, _lstr):
            return (
                self.text == other.text and
                self.language == other.language and
                self.metadata == other.metadata
            )
        return False 