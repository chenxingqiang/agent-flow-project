"""Message types for ELL2A."""

import time
import json
import logging
import jsonschema
from enum import Enum
from typing import Optional, Union, List, Dict, Any, cast, Callable, Set, ClassVar
import jsonschema.exceptions
from pydantic import BaseModel, Field, ConfigDict, model_validator, ValidationInfo, field_validator, ValidationError, computed_field
from datetime import datetime
import numpy as np

logger = logging.getLogger('agentflow.ell2a')

class MessageValidationError(Exception):
    """Message validation error."""
    pass

class LMPType(str, Enum):
    """Language Model Provider type enum."""
    AGENT = "agent"
    TOOL = "tool"
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    FUNCTION = "function"
    CUSTOM = "custom"

class MessageRole(str, Enum):
    """Message role enum."""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"
    FUNCTION = "function"

class MessageType(str, Enum):
    """Message type enum."""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    FILE = "file"
    CODE = "code"
    ERROR = "error"
    RESULT = "result"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    STATUS = "status"
    COMMAND = "command"

class ContentBlock(BaseModel):
    """Content block for structured message content."""
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        extra='allow'
    )

    type: MessageType = Field(default=MessageType.TEXT)
    text: Optional[str] = None
    image: Optional[str] = None
    image_detail: Optional[str] = None
    parsed: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @property
    def content(self) -> Optional[str]:
        """Get content based on type."""
        if self.type == MessageType.TEXT:
            return self.text
        elif self.type == MessageType.IMAGE:
            return self.image
        return None

    @content.setter
    def content(self, value: str) -> None:
        """Set content based on type."""
        if self.type == MessageType.TEXT:
            self.text = value
        elif self.type == MessageType.IMAGE:
            self.image = value

    def __str__(self) -> str:
        """String representation."""
        if self.type == MessageType.TEXT or self.type == MessageType.RESULT:
            return self.text or ""
        elif self.type == MessageType.IMAGE:
            return f"[Image: {self.image_detail or self.image or ''}]"
        return ""

class ContentWrapper:
    """Custom wrapper to support both string and list-like access to content."""

    def __init__(self, content):
        self._content = content

    def __eq__(self, other):
        """Allow direct comparison with the original content."""
        return self._content == other

    def __str__(self):
        """Return the original string content."""
        return str(self._content)

    def __repr__(self):
        """Return the original string representation."""
        return repr(self._content)

    def __getitem__(self, index):
        """Provide list-like access, converting to ContentBlock if needed."""
        if isinstance(self._content, str):
            if index == 0:
                return ContentBlock(text=self._content)
            raise IndexError("String content only has one block")
        return self._content[index]

    def __len__(self):
        """Return the length of the content."""
        if isinstance(self._content, str):
            return 1
        return len(self._content)

    def __iter__(self):
        """Provide iteration support."""
        if isinstance(self._content, str):
            yield ContentBlock(text=self._content)
        else:
            yield from self._content

    def model_dump(self, **kwargs):
        """Provide Pydantic serialization support."""
        if isinstance(self._content, str):
            return self._content
        return list(self._content)

    def model_dump_json(self, **kwargs):
        """Provide JSON serialization support."""
        return json.dumps(self.model_dump())

    def __pydantic_core__(self, mode):
        """Pydantic core serialization method."""
        from pydantic_core import core_schema

        def serialize(obj):
            """Serialize the content."""
            if isinstance(obj._content, str):
                return obj._content
            return list(obj._content)

        def validate(obj):
            """Validate the content."""
            return obj

        return core_schema.no_info_plain_validator_function(validate, 
            serialization=core_schema.plain_serializer_function_ser_schema(
                serialize, 
                return_schema=core_schema.union_schema([
                    core_schema.str_schema(), 
                    core_schema.list_schema(core_schema.any_schema())
                ])
            )
        )

class Message(BaseModel):
    """Message class for communication."""

    role: MessageRole
    content: Union[str, List[ContentBlock], ContentBlock]
    timestamp: float = Field(default_factory=lambda: time.time())
    metadata: Optional[Dict[str, Any]] = None
    type: MessageType = MessageType.TEXT
    metadata_schema: Optional[Dict[str, Any]] = Field(default=None, description="Optional JSON schema for metadata validation")

    model_config = ConfigDict(
        validate_assignment=True,
        arbitrary_types_allowed=True,
        use_enum_values=True,
        frozen=True,
        extra='forbid',
        populate_by_name=True
    )

    @field_validator('role', mode='before')
    @classmethod
    def validate_role(cls, v):
        """Validate role is a valid MessageRole."""
        if isinstance(v, str):
            try:
                return MessageRole(v.lower())
            except ValueError:
                # Log the validation error
                logger.error(f"Invalid role: {v}")
                # Raise a specific validation error matching the test expectation
                raise MessageValidationError("role must be a MessageRole")
        
        if not isinstance(v, MessageRole):
            # Log the validation error
            logger.error(f"Invalid role type: {type(v)}")
            raise MessageValidationError("role must be a MessageRole")
        
        return v

    @field_validator('content')
    @classmethod
    def validate_content(cls, v):
        """Validate content."""
        if isinstance(v, str):
            return v
        elif isinstance(v, ContentBlock):
            return [v]  # Convert single ContentBlock to list
        elif isinstance(v, list):
            if not all(isinstance(item, ContentBlock) for item in v):
                logger.error("All items in content list must be ContentBlock instances")
                raise ValueError("All items in content list must be ContentBlock instances")
            return v
        logger.error("Content must be a string, ContentBlock, or list of ContentBlocks")
        raise ValueError("Content must be a string, ContentBlock, or list of ContentBlocks")

    @field_validator('metadata', mode='before')
    @classmethod
    def validate_metadata(cls, v, info: ValidationInfo):
        """Validate metadata with advanced type checking and optional schema validation."""
        # If no metadata is provided, return None
        if v is None:
            return None

        # Ensure metadata is a dictionary
        if not isinstance(v, dict):
            logger.error("Metadata must be a dictionary")
            raise MessageValidationError("Metadata must be a dictionary")

        # Validate metadata types recursively with depth limit to prevent infinite recursion
        def validate_metadata_value(value, depth=0):
            """Recursively validate metadata value types."""
            # Prevent excessive recursion
            if depth > 10:
                return True

            # Handle enums by converting to their values
            if hasattr(value, '_value_'):
                value = value._value_

            # Allow primitive types and None
            if isinstance(value, (str, int, float, bool, type(None))):
                return True

            # Allow lists with validated elements
            if isinstance(value, list):
                return all(validate_metadata_value(item, depth+1) for item in value)

            # Allow dictionaries with string keys and validated values
            if isinstance(value, dict):
                # Prevent circular references by checking if the dict is referencing itself
                if value is v:
                    return True

                return all(
                    isinstance(k, str) and
                    validate_metadata_value(val, depth+1)
                    for k, val in value.items()
                )

            # Reject other types
            logger.error(f"Unsupported metadata type: {type(value)}")
            return False

        # Convert any enums in the top-level dictionary to their values
        processed_metadata = {}
        for key, value in v.items():
            if hasattr(value, '_value_'):
                processed_metadata[key] = value._value_
            else:
                processed_metadata[key] = value

        # Check if metadata contains only supported types
        if not validate_metadata_value(processed_metadata):
            logger.error("Metadata contains unsupported types")
            raise MessageValidationError("Metadata contains unsupported types")

        # Validate against JSON schema if provided
        metadata_schema = info.data.get('metadata_schema')
        if metadata_schema:
            try:
                import jsonschema
                jsonschema.validate(processed_metadata, metadata_schema)
            except jsonschema.ValidationError as e:
                logger.error(f"Metadata schema validation failed: {e}")
                raise MessageValidationError(f"Metadata schema validation failed: {e}")
            except ImportError:
                logger.warning("jsonschema package not installed, skipping schema validation")

        return processed_metadata

    def __init__(self, **data):
        """Initialize message."""
        # Extract metadata schema before validation
        metadata_schema = data.pop('metadata_schema', None)
        if metadata_schema:
            data['metadata_schema'] = metadata_schema
            # Validate metadata against schema
            if 'metadata' in data:
                try:
                    import jsonschema
                    jsonschema.validate(data['metadata'], metadata_schema)
                except jsonschema.ValidationError as e:
                    logger.error(f"Metadata schema validation failed: {e}")
                    raise MessageValidationError(f"Metadata schema validation failed: {e}")
                except ImportError:
                    logger.warning("jsonschema package not installed, skipping schema validation")

        super().__init__(**data)

    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary."""
        # Convert role to string value
        role_value = self.role.value if hasattr(self.role, 'value') else str(self.role)
        
        # Handle content, unwrapping ContentWrapper if needed
        if isinstance(self.content, ContentWrapper):
            content = self.content._content
        elif isinstance(self.content, list):
            # Handle list of content blocks
            if len(self.content) == 1:
                item = self.content[0]
                content = item if isinstance(item, str) else item.text or ""
            else:
                content = [
                    item if isinstance(item, str) else item.text or ""
                    for item in self.content
                ]
        else:
            content = self.content
        
        return {
            "role": role_value,
            "content": content,
            "metadata": self.metadata or {}
        }

    def to_json(self, **kwargs) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), **kwargs)

    def truncate(self, max_length: int) -> 'Message':
        """Truncate message content."""
        # Handle string content
        if isinstance(self.content, str):
            return Message(
                role=self.role,
                content=self.content[:max_length],
                metadata=self.metadata.copy() if self.metadata else {},
                timestamp=self.timestamp,
                type=self.type
            )
        
        # Handle ContentBlock
        if isinstance(self.content, ContentBlock):
            return Message(
                role=self.role,
                content=ContentBlock(
                    type=self.content.type,
                    text=self.content.text[:max_length] if self.content.text else None,
                    image=self.content.image,
                    image_detail=self.content.image_detail,
                    parsed=self.content.parsed,
                    metadata=self.content.metadata
                ),
                metadata=self.metadata.copy() if self.metadata else {},
                timestamp=self.timestamp,
                type=self.type
            )
        
        # Handle list of content blocks
        truncated_content = []
        for item in self.content:
            if isinstance(item, str):
                truncated_content.append(item[:max_length])
            else:
                truncated_content.append(ContentBlock(
                    type=item.type,
                    text=item.text[:max_length] if item.text else None,
                    image=item.image,
                    image_detail=item.image_detail,
                    parsed=item.parsed,
                    metadata=item.metadata
                ))
        
        # If there's only one item, return its text for backwards compatibility
        if len(truncated_content) == 1:
            item = truncated_content[0]
            return Message(
                role=self.role,
                content=item if isinstance(item, str) else item.text or "",
                metadata=self.metadata.copy() if self.metadata else {},
                timestamp=self.timestamp,
                type=self.type
            )
        
        return Message(
            role=self.role,
            content=truncated_content,
            metadata=self.metadata.copy() if self.metadata else {},
            timestamp=self.timestamp,
            type=self.type
        )

    def map_metadata(self, transform_fn: Callable[[str, Any], Any]) -> Dict[str, Any]:
        """Map metadata values using transform function.
        
        Args:
            transform_fn: Function taking key and value, returning transformed value
            
        Returns:
            Dict[str, Any]: Transformed metadata dictionary
        """
        return {k: transform_fn(k, v) for k, v in (self.metadata or {}).items()}

    def filter_metadata(self, filter_fn: Callable[[str, Any], bool]) -> Dict[str, Any]:
        """Filter metadata using a filter function.
        
        Args:
            filter_fn: Function taking key and value, returning bool
            
        Returns:
            Dict[str, Any]: Filtered metadata dictionary
        """
        return {k: v for k, v in (self.metadata or {}).items() if filter_fn(k, v)}

    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get metadata value for a given key.
        
        Args:
            key: Metadata key to retrieve
            default: Default value if key is not found
            
        Returns:
            Value associated with the key, or default if not found
        """
        return (self.metadata or {}).get(key, default)

    def __hash__(self):
        """Generate a hash for the message."""
        return hash((
            self.role, 
            (self.content._content if isinstance(self.content, ContentWrapper) 
             else self.content), 
            json.dumps(self.metadata, sort_keys=True) if self.metadata else None
        ))

    def __eq__(self, other):
        """Check equality with another message."""
        if not isinstance(other, Message):
            return False
        
        # Compare content, handling ContentWrapper
        content_equal = (
            (self.content._content if isinstance(self.content, ContentWrapper) else self.content) ==
            (other.content._content if isinstance(other.content, ContentWrapper) else other.content)
        )
        
        return (
            self.role == other.role and
            content_equal and
            self.metadata == other.metadata
        )

    def __str__(self) -> str:
        """String representation."""
        role_str = str(self.role).upper()
        metadata_str = f"(metadata: {len(self.metadata or {})} items)"
        return f"{role_str} {str(self.content)} {metadata_str}"

    def __repr__(self) -> str:
        """Get detailed string representation."""
        role_name = self.role.name.upper() if hasattr(self.role, 'name') else str(self.role).upper()
        return f"Message(role=MessageRole.{role_name}, content={repr(self.content)}, timestamp={self.timestamp}, metadata={repr(self.metadata)}, type={repr(self.type)})"

    @classmethod
    def from_json(cls, json_str: str, **kwargs) -> 'Message':
        """Create message from JSON string.
        
        Args:
            json_str: JSON string representation
            **kwargs: Additional arguments passed to Message constructor
            
        Returns:
            Message: New message instance
        """
        try:
            data = json.loads(json_str)
            
            # Convert role to enum
            if "role" in data and isinstance(data["role"], str):
                data["role"] = MessageRole(data["role"].lower())
                
            return cls(**{**data, **kwargs})
        except Exception as e:
            error_msg = str(e)
            logger.error(error_msg)
            raise MessageValidationError(error_msg) from e

    def copy(self, **kwargs) -> 'Message':
        """Create a copy of the message with optional overrides."""
        data = self.model_dump()
        data.update(kwargs)
        return Message(**data)

    def advanced_metadata_transform(self, transform_fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> 'Message':
        """Apply transformation function to metadata.
        
        Args:
            transform_fn: Function that takes metadata dict and returns transformed dict
            
        Returns:
            Message: New message with transformed metadata
        """
        transformed = transform_fn(dict(self.metadata or {}))
        return self.with_metadata(**transformed)

    def with_metadata(self, **kwargs) -> 'Message':
        """Create a new message with updated metadata.
        
        Args:
            **kwargs: Metadata key-value pairs to update
            
        Returns:
            Message: New message instance with updated metadata
        """
        current_metadata = dict(self.metadata or {})
        current_metadata.update(kwargs)
        return Message(
            role=self.role,
            content=self.content,  # Use content instead of content
            timestamp=self.timestamp,
            metadata=current_metadata,
            type=self.type
        )

class ToolResult(BaseModel):
    """Tool result class."""
    
    model_config = ConfigDict(
        validate_assignment=True,
        arbitrary_types_allowed=True,
        use_enum_values=True,
        frozen=True,
        extra='allow'
    )
    
    tool_call_id: str = Field(description="Tool call ID")
    result: List[ContentBlock] = Field(description="Tool result content blocks")

def system(content: str) -> Message:
    """Create a system message.
    
    Args:
        content: Message content
        
    Returns:
        System message
    """
    return Message(role=MessageRole.SYSTEM, content=content)

def user(content: str) -> Message:
    """Create a user message.
    
    Args:
        content: Message content
        
    Returns:
        User message
    """
    return Message(role=MessageRole.USER, content=content)

def assistant(content: str) -> Message:
    """Create an assistant message.
    
    Args:
        content: Message content
        
    Returns:
        Assistant message
    """
    return Message(role=MessageRole.ASSISTANT, content=content)

def function(content: str) -> Message:
    """Create a function message.
    
    Args:
        content: Message content
        
    Returns:
        Function message
    """
    return Message(role=MessageRole.FUNCTION, content=content)

def tool(content: str) -> Message:
    """Create a tool message.
    
    Args:
        content: Message content
        
    Returns:
        Tool message
    """
    return Message(role=MessageRole.TOOL, content=content) 

def to_content_blocks(items: List[Union[str, ContentBlock, tuple]]) -> List[ContentBlock]:
    """Convert items to content blocks."""
    blocks = []
    for item in items:
        if isinstance(item, ContentBlock):
            blocks.append(item)
        elif isinstance(item, str):
            blocks.append(ContentBlock(text=item))
        elif isinstance(item, tuple):
            if len(item) == 2:
                blocks.append(ContentBlock(text=str(item[0]), metadata={"type": str(item[1])}))
            else:
                blocks.append(ContentBlock(text=str(item[0])))
        else:
            blocks.append(ContentBlock(text=str(item)))
    return blocks 