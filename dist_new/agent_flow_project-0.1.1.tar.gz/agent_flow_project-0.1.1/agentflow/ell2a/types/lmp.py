"""LMP (Language Model Provider) type definitions."""

from enum import Enum

class LMPType(str, Enum):
    """Language Model Provider type enumeration."""
    LM = "LM"
    TOOL = "TOOL"
    LABELER = "LABELER"
    FUNCTION = "FUNCTION"
    OTHER = "OTHER" 