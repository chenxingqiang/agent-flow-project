"""Evaluation results for ELL2A."""

from enum import Enum
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from pydantic import BaseModel, Field, ConfigDict

class Label(str, Enum):
    """Evaluation label enumeration."""
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"

@dataclass
class _ResultDatapoint:
    """Result datapoint class."""
    output: Tuple[str, str]  # (output_text, invocation_id)
    labels: List[Label]
    metadata: Dict[str, Any]

class InvocationIds(BaseModel):
    """Invocation IDs class."""
    
    model_config = ConfigDict(
        validate_assignment=True,
        arbitrary_types_allowed=True,
        use_enum_values=True
    )
    
    outputs: List[str] = Field(default_factory=list)
    metrics: Dict[str, np.ndarray] = Field(default_factory=dict)
    annotations: Dict[str, np.ndarray] = Field(default_factory=dict)
    criterion: np.ndarray = Field(default_factory=lambda: np.array([]))

class EvaluationResults:
    """Evaluation results class."""
    
    def __init__(self):
        """Initialize results."""
        self.total = 0
        self.passed = 0
        self.failed = 0
        self.skipped = 0
        self.invocation_ids = InvocationIds()
        self._results: List[_ResultDatapoint] = []
        
    def add_result(self, label: Label, result: _ResultDatapoint) -> None:
        """Add result to results.
        
        Args:
            label: Result label
            result: Result datapoint
        """
        self.total += 1
        if label == Label.PASS:
            self.passed += 1
        elif label == Label.FAIL:
            self.failed += 1
        else:
            self.skipped += 1
            
        # Update invocation IDs
        output_text, invocation_id = result.output
        self.invocation_ids.outputs.append(invocation_id)
        
        # Update metrics
        for metric_name, metric_value in result.metadata.items():
            if isinstance(metric_value, (int, float)):
                if metric_name not in self.invocation_ids.metrics:
                    self.invocation_ids.metrics[metric_name] = np.array([])
                self.invocation_ids.metrics[metric_name] = np.append(
                    self.invocation_ids.metrics[metric_name],
                    invocation_id
                )
            else:
                if metric_name not in self.invocation_ids.annotations:
                    self.invocation_ids.annotations[metric_name] = np.array([])
                self.invocation_ids.annotations[metric_name] = np.append(
                    self.invocation_ids.annotations[metric_name],
                    invocation_id
                )
                
        # Update criterion
        self.invocation_ids.criterion = np.append(
            self.invocation_ids.criterion,
            invocation_id
        )
        
        self._results.append(result) 