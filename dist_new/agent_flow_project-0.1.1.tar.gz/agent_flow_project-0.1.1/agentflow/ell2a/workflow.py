"""ELL2A workflow module."""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from ..core.ell2a_integration import ell2a_integration
from .types.message import Message, MessageRole  # Update import to use correct Message type

@dataclass
class ELL2AWorkflow:
    """ELL2A workflow class."""
    
    name: str
    description: Optional[str] = None
    steps: List[Dict[str, Any]] = field(default_factory=list)
    
    def __post_init__(self):
        """Post initialization setup."""
        self.id = f"workflow_{self.name}"
        self._initialized = False
    
    async def initialize(self) -> None:
        """Initialize workflow."""
        if not self._initialized:
            # Register with ELL2A integration
            ell2a_integration.register_workflow(self.id, self)
            self._initialized = True
    
    def add_step(self, step: Dict[str, Any]):
        """Add a step to the workflow.
        
        Args:
            step: Step configuration
        """
        if not isinstance(step, dict):
            raise ValueError("Step must be a dictionary")
        
        required_fields = {"name", "type", "config"}
        missing_fields = required_fields - set(step.keys())
        if missing_fields:
            raise ValueError(f"Step missing required fields: {missing_fields}")
            
        self.steps.append(step)
    
    @ell2a_integration.track_function()
    @ell2a_integration.with_ell2a(mode="simple")
    async def run(self, context: Dict[str, Any]) -> Message:
        """Run the workflow.
        
        Args:
            context: Workflow context
            
        Returns:
            Message: Workflow results
        """
        # Initialize the workflow
        await self.initialize()

        # Process each step in sequence
        results = {}
        for step in self.steps:
            # Create a message for this step
            message = Message(
                role=MessageRole.USER,
                content=str(context),  # Convert context to string to ensure compatibility
                metadata={"step": step}
            )

            # Process the message
            response = await ell2a_integration.process_message(message)
            
            # Store the result
            results[step["name"]] = {
                "status": "success",
                "result": response.content,
                "metadata": response.metadata
            }

        # Create the final result message
        final_message = Message(
            role=MessageRole.ASSISTANT,
            content=str(response.content),  # Convert content to string
            metadata={
                "type": "workflow_output",
                "results": results
            }
        )

        return final_message
    
    @ell2a_integration.with_ell2a(mode="complex")
    async def _execute_step(self, step: Dict[str, Any], context: Any) -> Dict[str, Any]:
        """Execute a workflow step.
        
        Args:
            step: Step configuration
            context: Workflow context
            
        Returns:
            Dict[str, Any]: Step results
        """
        # Create step message
        message = ell2a_integration.create_message(
            role="user",
            content=str(context),
            metadata={
                "step_name": step["name"],
                "step_type": step["type"],
                "config": step["config"]
            }
        )
        
        # Process message
        response = await ell2a_integration.process_message(message)
        
        # Return step results
        return {
            "status": "success",
            "result": response.content,
            "metadata": response.metadata
        }
    
    def get_state(self) -> Dict[str, Any]:
        """Get workflow state."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "num_steps": len(self.steps),
            "initialized": self._initialized
        } 