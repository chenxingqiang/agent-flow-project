"""Tool module for ELL2A."""

import functools
from typing import Any, Callable, Dict, Optional, TypeVar, cast

T = TypeVar("T")

class ToolResult:
    """Result of a tool execution."""
    
    def __init__(
        self,
        data: Any,
        tool_call_id: Optional[str] = None,
        exempt_from_tracking: bool = False,
        invocation_origin: Optional[str] = None
    ):
        """Initialize tool result.
        
        Args:
            data: The result data of the tool execution
            tool_call_id: Optional tool call ID for tracking
            exempt_from_tracking: Whether this result is exempt from tracking
            invocation_origin: Optional origin of the invocation
        """
        self.data = data
        self.tool_call_id = tool_call_id
        self.exempt_from_tracking = exempt_from_tracking
        self.invocation_origin = invocation_origin

def tool(
    func: Optional[Callable[..., T]] = None,
    *,
    exempt_from_tracking: bool = False
) -> Callable[..., T]:
    """Decorator for tools.
    
    Args:
        func: The function to decorate
        exempt_from_tracking: Whether this tool is exempt from tracking
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Extract tool call ID and invocation origin if provided
            tool_call_id = kwargs.pop("_tool_call_id", None)
            invocation_origin = kwargs.pop("_invocation_origin", None)
            
            # Execute the function
            result = func(*args, **kwargs)
            
            # Wrap result in ToolResult if not already wrapped
            if not isinstance(result, ToolResult):
                result = ToolResult(
                    data=result,
                    tool_call_id=tool_call_id,
                    exempt_from_tracking=exempt_from_tracking,
                    invocation_origin=invocation_origin
                )
            
            return cast(T, result)
        
        return wrapper
    
    if func is None:
        return decorator
    return decorator(func) 