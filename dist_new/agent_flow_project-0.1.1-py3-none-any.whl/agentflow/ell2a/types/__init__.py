"""ELL2A types package."""

from .lmp import LMPType
from ._lstr import _lstr

__all__ = ['LMPType', '_lstr'] 