"""LMP (Language Model Provider) module."""

from ..types.lmp import LMPType
from .function import function, FunctionConfig

__all__ = ['LMPType', 'function', 'FunctionConfig'] 