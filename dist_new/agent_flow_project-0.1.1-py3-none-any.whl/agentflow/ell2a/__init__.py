"""ELL2A package."""

from agentflow.ell2a.types.message import Message, MessageRole, MessageType, MessageValidationError
from agentflow.ell2a.ell import ELL

def system(message: str) -> Message:
    """Create a system message.
    
    Args:
        message: The message content
        
    Returns:
        Message: A system message
    """
    return Message(
        role=MessageRole.SYSTEM,
        content=message,
        type=MessageType.TEXT
    )

def user(message: str) -> Message:
    """Create a user message.
    
    Args:
        message: The message content
        
    Returns:
        Message: A user message
    """
    return Message(
        role=MessageRole.USER,
        content=message,
        type=MessageType.TEXT
    )

def assistant(message: str) -> Message:
    """Create an assistant message.
    
    Args:
        message: The message content
        
    Returns:
        Message: An assistant message
    """
    return Message(
        role=MessageRole.ASSISTANT,
        content=message,
        type=MessageType.TEXT
    )

__all__ = [
    'Message',
    'MessageRole',
    'MessageType',
    'MessageValidationError',
    'ELL',
    'system',
    'user',
    'assistant'
] 