"""Evaluation module for ELL2A."""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union, Callable, Type
from pydantic import BaseModel, ConfigDict, Field

class EvaluationRun(BaseModel):
    """Single evaluation run."""
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    timestamp: datetime = Field(default_factory=datetime.now)
    input_data: Dict[str, Any] = Field(default_factory=dict)
    output_data: Dict[str, Any] = Field(default_factory=dict)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    metrics: Dict[str, Any] = Field(default_factory=dict)
    status: str = "pending"
    error: Optional[str] = None
    n_evals: int = 10
    samples_per_datapoint: int = 2

class Evaluation(BaseModel):
    """Evaluation class for ELL2A."""
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = Field(default_factory=dict)
    runs: List[EvaluationRun] = Field(default_factory=list)
    criterion: Optional[Callable[[Dict[str, Any]], bool]] = None
    n_evals: int = 10
    samples_per_datapoint: int = 2
    metrics: Dict[str, Any] = Field(default_factory=lambda: {"mock_metric": 0})
    
    def _process_single(
        self,
        data_point: Dict[str, Any],
        lmp: Type,
        lmp_params: Dict[str, Any],
        required_params: bool = True
    ) -> List[Any]:
        """Process a single data point.
        
        Args:
            data_point: Data point to process
            lmp: Language model provider
            lmp_params: Parameters for the language model
            required_params: Whether parameters are required
            
        Returns:
            List of processed results
        """
        # Validate input
        if not isinstance(data_point.get("input"), dict):
            raise ValueError(f"Invalid input type: {type(data_point.get('input'))}")
        
        # Create LMP instance with parameters
        if required_params and not lmp_params:
            raise ValueError("Parameters are required but none provided")
        
        try:
            # Process the input using the LMP
            result = lmp(param=data_point["input"], api_params=lmp_params)
            return [result]
        except Exception as e:
            return [str(e)]
    
    def run(
        self,
        lmp: Type,
        data: Optional[List[Dict[str, Any]]] = None,
        n_workers: int = 1,
        verbose: bool = False,
        **kwargs
    ) -> EvaluationRun:
        """Run evaluation.
        
        Args:
            lmp: Language model provider
            data: Input data for evaluation
            n_workers: Number of workers for parallel processing
            verbose: Whether to show verbose output
            **kwargs: Additional arguments
            
        Returns:
            Evaluation run
        """
        # Create evaluation run
        run = EvaluationRun(
            input_data={"lmp": lmp.__name__, "data": data},
            parameters=kwargs,
            timestamp=datetime.now(),
            n_evals=self.n_evals,
            samples_per_datapoint=self.samples_per_datapoint
        )
        
        try:
            # Process input data
            if data:
                results = []
                for data_point in data:
                    result = self._process_single(data_point, lmp, kwargs.get("lmp_params", {}))
                    results.extend(result)
                run.output_data["results"] = results
            else:
                # Single run without data
                result = lmp()
                run.output_data["result"] = result
            
            # Apply criterion if provided
            if self.criterion:
                run.metrics["criterion_met"] = self.criterion(run.output_data)
            
            run.status = "completed"
            
        except Exception as e:
            run.status = "failed"
            run.error = str(e)
        
        # Add run to list
        self.runs.append(run)
        
        return run 