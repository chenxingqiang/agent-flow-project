"""Configuration module for ELL2A."""

from typing import Dict, Optional


class ELL2AConfig:
    """Configuration class for ELL2A."""

    def __init__(self):
        """Initialize the configuration."""
        self.default_client = "OpenAIClient"
        self.registry: Dict[str, str] = {}
        self.autocommit_model = "test_model"

    def get_client_for(self, model_name: Optional[str] = None) -> Optional[str]:
        """Get client for model.

        Args:
            model_name: Optional model name

        Returns:
            Client name if found, None otherwise
        """
        return self.default_client


config = ELL2AConfig()

__all__ = ["config", "ELL2AConfig"] 