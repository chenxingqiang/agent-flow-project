"""Time utilities for ELL2A."""

from datetime import datetime, timezone

def utc_now() -> datetime:
    """Get current UTC time.
    
    Returns:
        Current UTC time
    """
    return datetime.now(timezone.utc) 