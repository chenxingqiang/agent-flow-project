"""Utility functions for checking if modules should be imported."""

import os
import sys
import site
import sysconfig
import importlib.util
from pathlib import Path
from typing import Optional

def should_import(module_name: str, raise_on_error: bool = False) -> bool:
    """Check if a module should be imported.
    
    Args:
        module_name: Name of the module to check.
        raise_on_error: Whether to raise an error if the module cannot be imported.
        
    Returns:
        bool: True if the module should be imported, False otherwise.
    """
    try:
        # Get module spec
        spec = importlib.util.find_spec(module_name)
        if spec is None:
            return False
            
        # Handle built-in modules and modules without location
        if not spec.has_location or spec.origin is None:
            # Allow standard library modules
            return module_name in sys.stdlib_module_names or module_name in sys.builtin_module_names
            
        # Get paths
        project_root = os.environ.get("PROJECT_ROOT", ".")
        site_packages = site.getsitepackages() + [site.getusersitepackages()]
        stdlib_path = sysconfig.get_paths()["stdlib"]
        
        # Convert paths to strings for comparison
        spec_origin = str(spec.origin)
        project_root = str(project_root)
        site_packages = [str(p) for p in site_packages]
        stdlib_path = str(stdlib_path)
        
        # Check if module is in standard library
        if spec_origin.startswith(stdlib_path):
            # Allow all standard library modules
            return True
            
        # Check if module is in site-packages
        if any(spec_origin.startswith(p) for p in site_packages):
            # Allow modules with ell2a prefix and some third-party modules
            return (
                module_name.startswith("ell2a.") or 
                module_name.startswith("ell2a_") or 
                module_name in ["numpy", "requests"]
            )
            
        # Check if module is in project root
        if spec_origin.startswith(project_root):
            # Only allow modules with ell2a prefix
            return module_name.startswith("ell2a.") or module_name.startswith("ell2a_")
            
        # Module is in additional paths or unknown location
        return False
        
    except Exception as e:
        if raise_on_error:
            raise ImportError(f"Error checking module {module_name}: {str(e)}") from e
        return True  # Return True on exceptions when raise_on_error is False

def is_module_available(module_name: str) -> bool:
    """Check if a module is available.
    
    Args:
        module_name: Name of module to check
        
    Returns:
        bool: True if module is available
    """
    return importlib.util.find_spec(module_name) is not None

def should_import_openai() -> bool:
    """Check if OpenAI should be imported.
    
    Returns:
        bool: True if OpenAI should be imported
    """
    return is_module_available("openai")

def should_import_alembic() -> bool:
    """Check if Alembic should be imported.
    
    Returns:
        bool: True if Alembic should be imported
    """
    return is_module_available("alembic")

def get_optional_import(module_name: str) -> Optional[object]:
    """Get optional module import.
    
    Args:
        module_name: Name of module to import
        
    Returns:
        Optional[object]: Imported module or None
    """
    try:
        return importlib.import_module(module_name)
    except ImportError:
        return None 