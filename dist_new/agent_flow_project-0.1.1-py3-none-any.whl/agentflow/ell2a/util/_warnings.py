"""Warnings utility for ELL2A."""

import functools
import logging
from typing import Any, Callable, Dict, Optional, TypeVar, cast

from colorama import Fore, Style

from ..config import config

logger = logging.getLogger(__name__)

def _no_api_key_warning(
    model_name: Optional[str] = None,
    client: Optional[str] = None,
    *,
    name: Optional[str] = None,
    long: bool = False,
    error: bool = False
) -> str:
    """Display warning about missing API key.
    
    Args:
        model_name: Optional model name
        client: Optional client name
        name: Optional LMP name
        long: Whether to use long format
        error: Whether to raise error
    
    Returns:
        Warning message
    """
    client = client or config.default_client
    model_str = f" for model {model_name}" if model_name else ""
    name_str = f" used by LMP `{name}`" if name else ""
    
    if error:
        # Use red color for error mode
        msg = f"{Fore.RED}ERROR: No API key found for {client}{model_str}{name_str}.{Style.RESET_ALL}"
        try:
            return msg
        finally:
            raise ValueError(msg.replace(Fore.RED, "").replace(Style.RESET_ALL, ""))
    elif long:
        msg = (
            f"{Fore.LIGHTYELLOW_EX}WARNING: No API key found for {client}{model_str}{name_str}.\n"
            f"To fix this:\n"
            f"1. Set your API key using the appropriate environment variable\n"
            f"2. Or configure it in your settings\n"
            f"3. Or specify a client explicitly{Style.RESET_ALL}"
        )
    else:
        msg = f"{Fore.LIGHTYELLOW_EX}WARNING: No API key found for {client}{model_str}{name_str}.{Style.RESET_ALL}"
    
    return msg

def _warnings(model_name: str, fn: Optional[Callable] = None, client: Optional[str] = None) -> Callable:
    """Decorator to handle warnings related to model registration and API key availability.
    
    Args:
        model_name: Name of the model
        fn: Function to decorate
        client: Optional client name
    
    Returns:
        Decorated function
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if model_name not in config.registry:
                msg = f"{Fore.LIGHTYELLOW_EX}WARNING: Model {model_name} is not registered in the registry.{Style.RESET_ALL}"
                logger.warning(msg)
            return func(*args, **kwargs)
        return wrapper
    
    # If fn is provided, apply the decorator immediately
    if fn is not None:
        return decorator(fn)
    return decorator

def _autocommit_warning() -> bool:
    """Display warning about using autocommit model.
    
    Returns:
        True to indicate warning was displayed
    """
    msg = f"{Fore.LIGHTYELLOW_EX}WARNING: Autocommit is enabled but no client found for {config.autocommit_model}. This may incur costs.{Style.RESET_ALL}"
    logger.warning(msg)
    return True