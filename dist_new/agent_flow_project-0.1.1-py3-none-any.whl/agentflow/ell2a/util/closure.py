"""Closure utilities for ELL2A.

This module provides utilities for handling closures in ELL2A, including:
- Getting closures for functions, classes, and modules
- Managing closure serialization and deserialization
"""

from typing import Any, Dict, List, Optional, Callable, Type
import inspect
import types
import sys
import builtins
from functools import wraps

def closure(func: Callable) -> Callable:
    """Decorator to handle closure serialization for functions.
    
    Args:
        func: Function to decorate
        
    Returns:
        Decorated function with closure handling
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Get closure variables
        closure_dict = get_closure_for_function(func)
        # Update function globals with closure variables
        func.__globals__.update(closure_dict)
        return func(*args, **kwargs)
    return wrapper

def get_closure_for_function(func: Callable) -> Dict[str, Any]:
    """Get closure variables for a function.
    
    Args:
        func: Function to get closure for
        
    Returns:
        Dictionary of closure variables
    """
    if not func.__closure__:
        return {}
        
    closure_dict = {}
    closure_vars = inspect.getclosurevars(func)
    
    # Add nonlocals
    closure_dict.update(closure_vars.nonlocals)
    
    # Add globals that are actually used
    used_globals = {
        name: value 
        for name, value in closure_vars.globals.items()
        if name in func.__code__.co_names
    }
    closure_dict.update(used_globals)
    
    return closure_dict

def get_closure_for_class(cls: Type) -> Dict[str, Any]:
    """Get closure variables for a class.
    
    Args:
        cls: Class to get closure for
        
    Returns:
        Dictionary of closure variables
    """
    closure_dict = {}
    
    # Get closure for class methods
    for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
        method_closure = get_closure_for_function(method)
        closure_dict.update(method_closure)
    
    # Get closure for class itself
    if hasattr(cls, '__closure__'):
        cls_closure = get_closure_for_function(cls)
        closure_dict.update(cls_closure)
    
    return closure_dict

def get_closure_for_module(module_name: str) -> Dict[str, Any]:
    """Get closure variables for a module.
    
    Args:
        module_name: Name of module to get closure for
        
    Returns:
        Dictionary of closure variables
    """
    closure_dict = {}
    
    try:
        module = sys.modules[module_name]
    except KeyError:
        return {}
    
    # Get module's global variables
    module_globals = module.__dict__
    
    # Add module-level variables
    for name, value in module_globals.items():
        # Skip private attributes and modules
        if name.startswith('_') or inspect.ismodule(value):
            continue
            
        # Check if the value belongs to this module
        value_module = getattr(value, '__module__', module_name)
        if value_module != module_name:
            continue
            
        # Add module-level functions
        if inspect.isfunction(value):
            closure_dict[name] = value
            func_closure = get_closure_for_function(value)
            closure_dict.update(func_closure)
            
        # Add module-level classes
        elif inspect.isclass(value):
            closure_dict[name] = value
            cls_closure = get_closure_for_class(value)
            closure_dict.update(cls_closure)
            
        # Add other module-level variables
        else:
            closure_dict[name] = value
    
    return closure_dict 