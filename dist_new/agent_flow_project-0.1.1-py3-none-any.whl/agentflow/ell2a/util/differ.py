"""Utility module for generating commit messages from code diffs."""

import difflib
from typing import Tuple, List, Any
from agentflow.ell2a.configurator import config
from agentflow.ell2a.types.message import Message, MessageRole

def analyze_changes(diff_lines: List[str]) -> str:
    """Analyze changes to determine commit type.
    
    Args:
        diff_lines: List of diff lines
        
    Returns:
        str: Commit type (feat, fix, refactor, etc.)
    """
    # Count different types of changes
    additions = 0
    deletions = 0
    modifications = 0
    
    # Look for specific patterns
    has_new_feature = False
    has_refactor = False
    has_bugfix = False
    
    # Track changes in function signatures, docstrings, and parameters
    signature_changes = False
    docstring_changes = False
    parameter_changes = False
    
    for line in diff_lines:
        if line.startswith('+'):
            additions += 1
            # Check for new function/class definitions
            if 'def ' in line or 'class ' in line:
                if not any(line.strip().startswith('+def ' + name) for name in ['joke', 'write_a_chord_progression_for_song']):
                    has_new_feature = True
                else:
                    signature_changes = True
            # Check for docstring changes
            elif '"""' in line or "'''" in line:
                docstring_changes = True
            # Check for parameter changes
            elif 'temperature=' in line or 'model=' in line:
                parameter_changes = True
                
        elif line.startswith('-'):
            deletions += 1
            # Check for removed function/class definitions
            if 'def ' in line or 'class ' in line:
                signature_changes = True
            # Check for docstring changes
            elif '"""' in line or "'''" in line:
                docstring_changes = True
            # Check for parameter changes
            elif 'temperature=' in line or 'model=' in line:
                parameter_changes = True
                
        else:
            modifications += 1
            
        # Check for refactoring patterns
        if ('def ' in line or 'class ' in line) and not has_new_feature:
            has_refactor = True
            
        # Check for bug fix patterns
        if 'fix' in line.lower() or 'bug' in line.lower():
            has_bugfix = True
            
    # Determine commit type based on patterns
    if signature_changes or docstring_changes or parameter_changes:
        return 'refactor'
    elif has_bugfix:
        return 'fix'
    elif has_new_feature:
        return 'feat'
    elif has_refactor:
        return 'refactor'
    elif deletions > additions:
        return 'chore'
    else:
        return 'feat'  # Default to feat if no clear pattern

def write_commit_message_for_diff(before_code: str, after_code: str) -> Tuple[str, List[Any]]:
    """Generate a commit message by analyzing the differences between two code versions.
    
    Args:
        before_code: The original code
        after_code: The modified code
        
    Returns:
        A tuple containing the commit message and any additional arguments
    """
    # Generate the diff
    diff = list(difflib.unified_diff(
        before_code.splitlines(keepends=True),
        after_code.splitlines(keepends=True),
        fromfile="before",
        tofile="after"
    ))
    
    # Analyze changes to determine commit type
    commit_type = analyze_changes(diff)
    
    # Format the commit message using the template
    commit_message = f"{commit_type}: " + config.commit_message_template.format(
        message=f"Updated code with {len(diff)} changes"
    )
    
    return commit_message, diff 