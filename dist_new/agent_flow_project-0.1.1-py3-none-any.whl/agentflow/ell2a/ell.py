"""ELL (Enhanced Language Learning) module."""

from typing import List, Dict, Any, Optional, Callable
from pydantic import BaseModel, Field, ConfigDict
import logging
from agentflow.ell2a.types.message import Message, MessageRole, MessageType

logger = logging.getLogger(__name__)

class ELL(BaseModel):
    """Enhanced Language Learning (ELL) class for message processing."""
    
    name: str = Field(default="default", description="Name of the model to use")
    config: Dict[str, Any] = Field(default_factory=dict, description="Model configuration")
    messages: List[Message] = Field(default_factory=list, description="Message history")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    process_message_fn: Optional[Callable[[Message], Message]] = Field(default=None, description="Message processing function")
    
    model_config = ConfigDict(
        validate_assignment=True,
        arbitrary_types_allowed=True,
        protected_namespaces=()
    )
    
    @property
    def conversation_history(self) -> List[Message]:
        """Get the conversation history."""
        return self.messages
    
    def get_history(self) -> List[Message]:
        """Get the conversation history."""
        return self.messages
    
    def get_messages(self) -> List[Message]:
        """Get the list of messages.
        
        Returns:
            List of messages in the conversation history.
        """
        return self.messages
    
    async def process_message(self, message: Message) -> Message:
        """Process a message.
        
        Args:
            message: Message to process
            
        Returns:
            Processed message
        """
        if not isinstance(message, Message):
            raise TypeError(f"Expected Message object, got {type(message)}")
        
        logger.debug("Message validation passed")
        self.messages.append(message)
        
        if self.process_message_fn:
            response = self.process_message_fn(message)
        else:
            # Default echo behavior
            metadata = message.metadata or {}
            response = Message(
                content=message.content,
                role=MessageRole.ASSISTANT,
                type=message.type,
                metadata={
                    "role": MessageRole.ASSISTANT,
                    "type": metadata.get("type", MessageType.TEXT),
                    "status": "success"
                }
            )
        self.messages.append(response)
        return response
    
    def add_message(self, message: Message) -> None:
        """Add a message to the conversation history.
        
        Args:
            message: Message to add
        """
        self.messages.append(message)
    
    def clear_messages(self) -> None:
        """Clear message history."""
        self.messages.clear()
    
    def clear_history(self) -> None:
        """Clear message history (alias for clear_messages)."""
        self.clear_messages()