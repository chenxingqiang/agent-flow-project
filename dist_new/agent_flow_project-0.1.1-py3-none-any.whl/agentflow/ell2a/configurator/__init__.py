"""ELL2A configurator module."""

from typing import Any, Dict, Optional, Tuple
from pydantic import BaseModel, ConfigDict

class ELL2AConfig(BaseModel):
    """Configuration for ELL2A."""
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    # Default configuration values
    default_model: str = "gpt-4o-mini"
    max_tokens: int = 2048
    temperature: float = 0.7
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stop_sequences: list[str] = []
    
    # Auto-commit configuration
    auto_commit: bool = True
    commit_message_template: str = "feat: {message}"
    branch_name_template: str = "feature/{name}"

class Configurator:
    """Configuration manager for ELL2A."""
    
    def __init__(self):
        """Initialize configurator."""
        self.registry: Dict[str, Any] = {}
        self.default_client = "OpenAIClient"
        self.autocommit_model = "gpt-3.5-turbo"
    
    def get_client_for(self, model_name: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
        """Get client for model.
        
        Args:
            model_name: Optional model name
            
        Returns:
            Tuple of client name and API key
        """
        # For testing purposes, return None to trigger warnings
        return None, None

# Create instances
config = ELL2AConfig()
configurator = Configurator()

__all__ = ['config', 'configurator', 'ELL2AConfig', 'Configurator'] 