"""Database migrations for ELL2A."""

import os
from pathlib import Path
from typing import Optional
from alembic.config import Config
from alembic import command

def get_alembic_config(db_url: Optional[str] = None) -> Config:
    """Get Alembic configuration.
    
    Args:
        db_url: Optional database URL
        
    Returns:
        Config: Alembic configuration
    """
    # Get package directory
    package_dir = Path(__file__).parent.parent
    
    # Create config
    config = Config()
    config.set_main_option("script_location", str(package_dir / "stores" / "migrations"))
    
    # Set database URL
    if db_url:
        config.set_main_option("sqlalchemy.url", db_url)
    elif "DATABASE_URL" in os.environ:
        config.set_main_option("sqlalchemy.url", os.environ["DATABASE_URL"])
        
    return config

def init_or_migrate_database(db_url: Optional[str] = None) -> None:
    """Initialize or migrate database.
    
    Args:
        db_url: Optional database URL
    """
    config = get_alembic_config(db_url)
    
    try:
        # Try to upgrade to head
        command.upgrade(config, "head")
    except Exception as e:
        # If upgrade fails, try to initialize and upgrade
        command.init(config, "migrations")
        command.upgrade(config, "head") 