"""SQL store for ELL2A."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from sqlmodel import Field, Session, SQLModel, create_engine, select, JSON
from sqlalchemy import Engine, func, inspect
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import MetaData
from sqlalchemy import Table, Column, Integer, String, JSON as JSONType, DateTime
from sqlalchemy.schema import CreateTable
import json

from ..types.lmp import LMPType
from ..util.time import utc_now

# Create a custom MetaData instance that allows table redefinition
metadata = MetaData()

class CustomSQLModel(SQLModel):
    """Custom SQLModel base class with metadata configuration."""
    class Config:
        table = False  # This is an abstract base class
        metadata = metadata

# Create Base for SQLAlchemy models
Base = declarative_base(metadata=metadata)

class SerializedLMP(Base):
    """Serialized LMP model."""
    __tablename__ = 'serializedlmp'
    __table_args__ = {'extend_existing': True}
    
    id = Column(Integer, primary_key=True)
    type = Column(String)
    name = Column(String)
    description = Column(String, nullable=True)
    parameters = Column(JSONType, default={})
    api_params = Column(JSONType, default={})
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now)
    
    def __init__(self, **data):
        """Initialize SerializedLMP."""
        super().__init__(**data)
        if isinstance(self.parameters, str):
            self.parameters = json.loads(self.parameters)
        if isinstance(self.api_params, str):
            self.api_params = json.loads(self.api_params)
            
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
            "api_params": self.api_params,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }

class SQLStore:
    """SQL store for ELL2A."""
    
    def __init__(self, engine: Engine):
        """Initialize SQL store.
        
        Args:
            engine: SQLAlchemy engine
        """
        self.engine = engine
        
        # Ensure tables are created with a new session
        with Session(self.engine) as session:
            Base.metadata.create_all(self.engine)
            session.commit()  # Commit to ensure table creation
    
    def write_lmp(self, lmp: Dict[str, Any]) -> SerializedLMP:
        """Write LMP to store.
        
        Args:
            lmp: LMP data
            
        Returns:
            Serialized LMP
        """
        with Session(self.engine) as session:
            serialized = SerializedLMP(
                type=lmp["type"],
                name=lmp["name"],
                description=lmp.get("description"),
                parameters=lmp.get("parameters", {}),
                api_params=lmp.get("api_params", {})
            )
            session.add(serialized)
            session.commit()
            session.refresh(serialized)
            return serialized
    
    def read_lmp(self, lmp_id: int) -> Optional[SerializedLMP]:
        """Read LMP from store.
        
        Args:
            lmp_id: LMP ID
            
        Returns:
            Serialized LMP if found, None otherwise
        """
        with Session(self.engine) as session:
            return session.get(SerializedLMP, lmp_id)
    
    def list_lmps(self, type_filter: Optional[LMPType] = None) -> List[SerializedLMP]:
        """List LMPs in store.
        
        Args:
            type_filter: Filter by LMP type
            
        Returns:
            List of serialized LMPs
        """
        with Session(self.engine) as session:
            query = select(SerializedLMP)
            if type_filter:
                query = query.where(SerializedLMP.type == type_filter)
            return list(session.exec(query)) 